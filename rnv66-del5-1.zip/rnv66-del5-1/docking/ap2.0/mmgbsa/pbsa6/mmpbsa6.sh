#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/rnv66-del5-1/docking/ap2.0/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com40-3.dat -cp $dir/com40-3.prmtop -rp $dir/com40-3-rec.prmtop -lp $dir/com40-3-lig.prmtop -y $dir/rnv66-del-40-3-eq2.xtc -sp $dir/com40-3-all.prmtop
