#!/bin/bash

# Use . as the decimal separator
export LC_NUMERIC=en_US.UTF-8
# Rang and spacing of the reaction coordinate
MIN_WINDOW=1
MAX_WINDOW=3
WINDOW_STEP=1

for win in $(seq ${MIN_WINDOW} ${WINDOW_STEP} ${MAX_WINDOW})
do

/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/amb2gro_top_gro.py -p com80-$win-all.prmtop -c com80-$win-all.inpcrd -t rnv66-del-80-$win.top -g rnv66-del-80-$win.gro -b rnv66-del-80-$win.pdb
/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/amb2gro_top_gro.py -p com90-$win-all.prmtop -c com90-$win-all.inpcrd -t rnv66-del-90-$win.top -g rnv66-del-90-$win.gro -b rnv66-del-90-$win.pdb

done

