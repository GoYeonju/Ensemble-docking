#!/bin/csh

setenv OMP_NUM_THREADS 1  
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

$GMXROOT/bin/gmx_mpi grompp -p rnv66-del-40-2.top -c rnv66-del-40-2.pdb -f min.mdp -o rnv66-del-40-2-min.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm rnv66-del-40-2-min
$GMXROOT/bin/gmx_mpi grompp -p rnv66-del-40-2.top -c rnv66-del-40-2-min.gro -f equi1.mdp -o rnv66-del-40-2-eq1.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm rnv66-del-40-2-eq1
$GMXROOT/bin/gmx_mpi grompp -p rnv66-del-40-2.top -c rnv66-del-40-2-eq1.gro -f eq.mdp -o rnv66-del-40-2-eq2.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm rnv66-del-40-2-eq2
echo 0 | $GMXROOT/bin/gmx_mpi trjconv -f rnv66-del-40-2-eq2.trr -o rnv66-del-40-2-eq2.xtc 
rm rnv66-del-40-2-eq2.trr 
#rm rnv66-del-40-2-eq2.edr 
