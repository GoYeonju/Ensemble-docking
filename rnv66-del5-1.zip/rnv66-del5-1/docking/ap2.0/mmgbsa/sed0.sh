#!/bin/bash

# Use . as the decimal separator
export LC_NUMERIC=en_US.UTF-8

# Rang and spacing of the reaction coordinate
MIN_WINDOW=1
MAX_WINDOW=3
WINDOW_STEP=1

for win in $(seq ${MIN_WINDOW} ${WINDOW_STEP} ${MAX_WINDOW})
do

sed -n 1,7625p com30-$win.pdb -i
sed -n 1,7625p com40-$win.pdb -i
sed -n 1,7625p com50-$win.pdb -i 
sed -n 1,7625p com60-$win.pdb -i 
sed -n 1,7625p com70-$win.pdb -i 
sed -n 1,7625p com80-$win.pdb -i 
sed -n 1,7625p com90-$win.pdb -i 

sed -n 1,2726p com30-$win-lig.pdb -i
sed -n 1,2726p com40-$win-lig.pdb -i
sed -n 1,2726p com50-$win-lig.pdb -i 
sed -n 1,2726p com60-$win-lig.pdb -i 
sed -n 1,2726p com70-$win-lig.pdb -i 
sed -n 1,2726p com80-$win-lig.pdb -i 
sed -n 1,2726p com90-$win-lig.pdb -i 

done
