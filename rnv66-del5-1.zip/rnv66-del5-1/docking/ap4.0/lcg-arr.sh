#!/bin/csh

set i = 30 
while($i < 91)
set name = `printf "%i" $i`

head -n 5025 com$name-1-test.pdb > file$name-1-1.txt
sed -n '7519,7553p' com$name-1-test.pdb > file$name-1-2.txt
sed -n '5026,5509p' com$name-1-test.pdb > file$name-1-3.txt
sed -n '7554,7588p' com$name-1-test.pdb > file$name-1-4.txt
sed -n '5510,5573p' com$name-1-test.pdb > file$name-1-5.txt
sed -n '7589,7623p' com$name-1-test.pdb > file$name-1-6.txt
sed -n '5574,7518p' com$name-1-test.pdb > file$name-1-7.txt
sed -n '7624,7627p' com$name-1-test.pdb > file$name-1-8.txt
cat file$name-1-1.txt file$name-1-2.txt file$name-1-3.txt file$name-1-4.txt file$name-1-5.txt file$name-1-6.txt file$name-1-7.txt file$name-1-8.txt > com$name-1.pdb
head -n 5025 com$name-2-test.pdb > file$name-2-1.txt
sed -n '7519,7553p' com$name-2-test.pdb > file$name-2-2.txt
sed -n '5026,5509p' com$name-2-test.pdb > file$name-2-3.txt
sed -n '7554,7588p' com$name-2-test.pdb > file$name-2-4.txt
sed -n '5510,5573p' com$name-2-test.pdb > file$name-4.0.txt
sed -n '7589,7623p' com$name-2-test.pdb > file$name-2-6.txt
sed -n '5574,7518p' com$name-2-test.pdb > file$name-2-7.txt
sed -n '7624,7627p' com$name-2-test.pdb > file$name-2-8.txt
cat file$name-2-1.txt file$name-2-2.txt file$name-2-3.txt file$name-2-4.txt file$name-4.0.txt file$name-2-6.txt file$name-2-7.txt file$name-2-8.txt > com$name-2.pdb

head -n 5025 com$name-3-test.pdb > file$name-3-1.txt
sed -n '7519,7553p' com$name-3-test.pdb > file$name-3-2.txt
sed -n '5026,5509p' com$name-3-test.pdb > file$name-3-3.txt
sed -n '7554,7588p' com$name-3-test.pdb > file$name-3-4.txt
sed -n '5510,5573p' com$name-3-test.pdb > file$name-3-5.txt
sed -n '7589,7623p' com$name-3-test.pdb > file$name-3-6.txt
sed -n '5574,7518p' com$name-3-test.pdb > file$name-3-7.txt
sed -n '7624,7627p' com$name-3-test.pdb > file$name-3-8.txt
cat file$name-3-1.txt file$name-3-2.txt file$name-3-3.txt file$name-3-4.txt file$name-3-5.txt file$name-3-6.txt file$name-3-7.txt file$name-3-8.txt > com$name-3.pdb

	@ i = $i + 10
end
 

