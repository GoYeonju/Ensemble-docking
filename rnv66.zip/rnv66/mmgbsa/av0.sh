#!/bin/csh

./av.x total-num-60-3.xvg av-total-60-3.txt
./av.x total-num-90-3.xvg av-total-90-3.txt
./av.x total-num-60-2.xvg av-total-60-2.txt
./av.x total-num-70-3.xvg av-total-70-3.txt
./av.x total-num-50-2.xvg av-total-50-2.txt
./av.x total-num-30-1.xvg av-total-30-1.txt
./av.x total-num-50-3.xvg av-total-50-3.txt
./av.x total-num-40-1.xvg av-total-40-1.txt
./av.x total-num-50-1.xvg av-total-50-1.txt
./av.x total-num-30-2.xvg av-total-30-2.txt
