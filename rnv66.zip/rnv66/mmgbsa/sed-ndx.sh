sed -n '/9TYR/p'  rnv66-30-2-eq.gro  | awk '{print $3}' > 9tyr.ndx
sed -n '/13TYR/p' rnv66-30-2-eq.gro  | awk '{print $3}' > 13tyr.ndx
sed -n '/50ASN/p' rnv66-30-2-eq.gro  | awk '{print $3}' > 50asn.ndx
sed -n '/52GLU/p' rnv66-30-2-eq.gro  | awk '{print $3}' > 52glu.ndx
sed -n '/51ASP/p' rnv66-30-2-eq.gro  | awk '{print $3}' > 51asp.ndx
sed -n '/31ILE/p' rnv66-30-2-eq.gro  | awk '{print $3}' > 31ile.ndx
sed -n '/77GLN/p' rnv66-30-2-eq.gro  | awk '{print $3}' > 77GLN.ndx
cat protein.txt 9tyr.ndx  dna.ndx > 9tyr-dna.ndx  
cat protein.txt 13tyr.ndx dna.ndx > 13tyr-dna.ndx 
cat protein.txt 50asn.ndx dna.ndx > 50asn-dna.ndx 
cat protein.txt 52glu.ndx dna.ndx > 52glu-dna.ndx 
cat protein.txt 51asp.ndx dna.ndx > 51asp-dna.ndx 
cat protein.txt 31ile.ndx dna.ndx > 31ile-dna.ndx 
cat protein.txt 77GLN.ndx dna.ndx > 77GLN-dna.ndx 

