#!/bin/csh

sed -i'' -r -e "/OXT/a\TER" com*.pdb

