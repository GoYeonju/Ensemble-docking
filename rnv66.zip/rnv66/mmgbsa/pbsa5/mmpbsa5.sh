#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/rnv66/docking/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com40-2.dat -cp $dir/com40-2.prmtop -rp $dir/com40-2-rec.prmtop -lp $dir/com40-2-lig.prmtop -y $dir/rnv66-40-2-eq2.xtc -sp $dir/com40-2-all.prmtop
