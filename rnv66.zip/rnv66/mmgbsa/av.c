#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

int main(int argc, char* argv[])
{
	int i, j, k;
	FILE *in, *out, *out2;
	double x,y;
	double sum = 0;
	char c;
	char buf[256];

		int N=0;
		in = fopen(argv[1], "r");

			while((c = fgetc(in)) != EOF){
				if(c == '\n'){
					N++;
				}
			}
		printf("%d\n", N);
		fclose(in);

                in = fopen(argv[1], "r");                                                                                                  
                out = fopen(argv[2], "w"); 
                for(j=0; j<N; j++){ 
				                                                                                                   
                        fscanf(in, "%lf\n", &x);
			sum = sum + x;
		}	
                fprintf(out, "%lf\n", sum/N);
			
                fclose(in);                                                                                                            
                fclose(out); 
	return 0;                                                                                                         
}        



