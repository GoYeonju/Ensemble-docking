#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/rnv66/docking/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com70-3.dat -cp $dir/com70-3.prmtop -rp $dir/com70-3-rec.prmtop -lp $dir/com70-3-lig.prmtop -y $dir/rnv66-70-3-eq2.xtc -sp $dir/com70-3-all.prmtop
