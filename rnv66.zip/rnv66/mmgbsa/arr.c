#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 10000

typedef struct {
    char string[100];
    double value;
} Data;

void selectionSort(Data arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j].value < arr[minIndex].value) {
                minIndex = j;
            }
        }
        // 최솟값과 현재 위치의 값을 교환
        Data temp = arr[i];
        arr[i] = arr[minIndex];
        arr[minIndex] = temp;
    }
}

int main(int argc, char* argv[]) {
    FILE *file;
    Data data[MAX_SIZE];
    int count = 0;
	char buf[256];

    // 파일 열기
    file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("파일을 열 수 없습니다.");
        return 1;
    }

    // 파일에서 데이터 읽기
    while (fscanf(file, "%s %lf", data[count].string, &data[count].value) != EOF) {
        count++;
    }

    // 선택 정렬을 사용하여 데이터 정렬
    selectionSort(data, count);

    // 가장 작은 세 개의 수를 포함한 열 출력
//    printf("가장 작은 세 개의 수를 포함한 열:\n");
    for (int i = 0; i < count; i++) {
        printf("%s %.2lf\n", data[i].string, data[i].value);
        if (i == 2) {
            break;
        }
    }

    // 파일 닫기
    fclose(file);
    return 0;
}

