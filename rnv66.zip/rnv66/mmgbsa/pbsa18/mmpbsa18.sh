#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/rnv66/docking/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com80-3.dat -cp $dir/com80-3.prmtop -rp $dir/com80-3-rec.prmtop -lp $dir/com80-3-lig.prmtop -y $dir/rnv66-80-3-eq2.xtc -sp $dir/com80-3-all.prmtop
