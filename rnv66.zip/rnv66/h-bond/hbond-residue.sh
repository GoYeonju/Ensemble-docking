#!/bin/csh

setenv OMP_NUM_THREADS 1 
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-30-1-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-30-1-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-30-1-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-30-1-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-30-1-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-30-1-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-1-mol.xtc -s rnv66-30-1-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-30-1-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-90-3-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-90-3-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-90-3-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-90-3-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-90-3-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-90-3-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-90-3-mol.xtc -s rnv66-90-3-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-90-3-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-70-3-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-70-3-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-70-3-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-70-3-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-70-3-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-70-3-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-70-3-mol.xtc -s rnv66-70-3-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-70-3-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-60-3-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-60-3-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-60-3-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-60-3-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-60-3-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-60-3-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-3-mol.xtc -s rnv66-60-3-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-60-3-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-60-2-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-60-2-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-60-2-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-60-2-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-60-2-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-60-2-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-60-2-mol.xtc -s rnv66-60-2-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-60-2-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-50-3-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-50-3-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-50-3-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-50-3-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-50-3-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-50-3-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-3-mol.xtc -s rnv66-50-3-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-50-3-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-50-2-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-50-2-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-50-2-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-50-2-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-50-2-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-50-2-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-2-mol.xtc -s rnv66-50-2-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-50-2-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-50-1-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-50-1-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-50-1-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-50-1-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-50-1-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-50-1-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-50-1-mol.xtc -s rnv66-50-1-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-50-1-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-40-1-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-40-1-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-40-1-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-40-1-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-40-1-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-40-1-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-40-1-mol.xtc -s rnv66-40-1-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-40-1-9tyr-dna

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 13tyr-dna.ndx -num num-30-2-13tyr-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 31ile-dna.ndx -num num-30-2-31ile-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 50asn-dna.ndx -num num-30-2-50asn-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 51asp-dna.ndx -num num-30-2-51asp-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 52glu-dna.ndx -num num-30-2-52glu-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 77GLN-dna.ndx -num num-30-2-77GLN-dna
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f rnv66-30-2-mol.xtc -s rnv66-30-2-eq2.tpr -b 10000 -n 9tyr-dna.ndx  -num num-30-2-9tyr-dna
