#!/bin/csh

sed -n 26,526p num-30-1-13tyr-dna.xvg  | awk '{print $2}' > total-num-30-1-13tyr-dna.xvg
sed -n 26,526p num-30-1-31ile-dna.xvg  | awk '{print $2}' > total-num-30-1-31ile-dna.xvg
sed -n 26,526p num-30-1-50asn-dna.xvg  | awk '{print $2}' > total-num-30-1-50asn-dna.xvg
sed -n 26,526p num-30-1-51asp-dna.xvg  | awk '{print $2}' > total-num-30-1-51asp-dna.xvg
sed -n 26,526p num-30-1-52glu-dna.xvg  | awk '{print $2}' > total-num-30-1-52glu-dna.xvg
sed -n 26,526p num-30-1-77GLN-dna.xvg  | awk '{print $2}' > total-num-30-1-77GLN-dna.xvg
sed -n 26,526p num-30-1-9tyr-dna.xvg   | awk '{print $2}' > total-num-30-1-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-90-3-13tyr-dna.xvg  | awk '{print $2}' > total-num-90-3-13tyr-dna.xvg
sed -n 26,526p num-90-3-31ile-dna.xvg  | awk '{print $2}' > total-num-90-3-31ile-dna.xvg
sed -n 26,526p num-90-3-50asn-dna.xvg  | awk '{print $2}' > total-num-90-3-50asn-dna.xvg
sed -n 26,526p num-90-3-51asp-dna.xvg  | awk '{print $2}' > total-num-90-3-51asp-dna.xvg
sed -n 26,526p num-90-3-52glu-dna.xvg  | awk '{print $2}' > total-num-90-3-52glu-dna.xvg
sed -n 26,526p num-90-3-77GLN-dna.xvg  | awk '{print $2}' > total-num-90-3-77GLN-dna.xvg
sed -n 26,526p num-90-3-9tyr-dna.xvg   | awk '{print $2}' > total-num-90-3-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-70-3-13tyr-dna.xvg  | awk '{print $2}' > total-num-70-3-13tyr-dna.xvg
sed -n 26,526p num-70-3-31ile-dna.xvg  | awk '{print $2}' > total-num-70-3-31ile-dna.xvg
sed -n 26,526p num-70-3-50asn-dna.xvg  | awk '{print $2}' > total-num-70-3-50asn-dna.xvg
sed -n 26,526p num-70-3-51asp-dna.xvg  | awk '{print $2}' > total-num-70-3-51asp-dna.xvg
sed -n 26,526p num-70-3-52glu-dna.xvg  | awk '{print $2}' > total-num-70-3-52glu-dna.xvg
sed -n 26,526p num-70-3-77GLN-dna.xvg  | awk '{print $2}' > total-num-70-3-77GLN-dna.xvg
sed -n 26,526p num-70-3-9tyr-dna.xvg   | awk '{print $2}' > total-num-70-3-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-60-3-13tyr-dna.xvg  | awk '{print $2}' > total-num-60-3-13tyr-dna.xvg
sed -n 26,526p num-60-3-31ile-dna.xvg  | awk '{print $2}' > total-num-60-3-31ile-dna.xvg
sed -n 26,526p num-60-3-50asn-dna.xvg  | awk '{print $2}' > total-num-60-3-50asn-dna.xvg
sed -n 26,526p num-60-3-51asp-dna.xvg  | awk '{print $2}' > total-num-60-3-51asp-dna.xvg
sed -n 26,526p num-60-3-52glu-dna.xvg  | awk '{print $2}' > total-num-60-3-52glu-dna.xvg
sed -n 26,526p num-60-3-77GLN-dna.xvg  | awk '{print $2}' > total-num-60-3-77GLN-dna.xvg
sed -n 26,526p num-60-3-9tyr-dna.xvg   | awk '{print $2}' > total-num-60-3-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-60-2-13tyr-dna.xvg  | awk '{print $2}' > total-num-60-2-13tyr-dna.xvg
sed -n 26,526p num-60-2-31ile-dna.xvg  | awk '{print $2}' > total-num-60-2-31ile-dna.xvg
sed -n 26,526p num-60-2-50asn-dna.xvg  | awk '{print $2}' > total-num-60-2-50asn-dna.xvg
sed -n 26,526p num-60-2-51asp-dna.xvg  | awk '{print $2}' > total-num-60-2-51asp-dna.xvg
sed -n 26,526p num-60-2-52glu-dna.xvg  | awk '{print $2}' > total-num-60-2-52glu-dna.xvg
sed -n 26,526p num-60-2-77GLN-dna.xvg  | awk '{print $2}' > total-num-60-2-77GLN-dna.xvg
sed -n 26,526p num-60-2-9tyr-dna.xvg   | awk '{print $2}' > total-num-60-2-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-50-3-13tyr-dna.xvg  | awk '{print $2}' > total-num-50-3-13tyr-dna.xvg
sed -n 26,526p num-50-3-31ile-dna.xvg  | awk '{print $2}' > total-num-50-3-31ile-dna.xvg
sed -n 26,526p num-50-3-50asn-dna.xvg  | awk '{print $2}' > total-num-50-3-50asn-dna.xvg
sed -n 26,526p num-50-3-51asp-dna.xvg  | awk '{print $2}' > total-num-50-3-51asp-dna.xvg
sed -n 26,526p num-50-3-52glu-dna.xvg  | awk '{print $2}' > total-num-50-3-52glu-dna.xvg
sed -n 26,526p num-50-3-77GLN-dna.xvg  | awk '{print $2}' > total-num-50-3-77GLN-dna.xvg
sed -n 26,526p num-50-3-9tyr-dna.xvg   | awk '{print $2}' > total-num-50-3-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-50-2-13tyr-dna.xvg  | awk '{print $2}' > total-num-50-2-13tyr-dna.xvg
sed -n 26,526p num-50-2-31ile-dna.xvg  | awk '{print $2}' > total-num-50-2-31ile-dna.xvg
sed -n 26,526p num-50-2-50asn-dna.xvg  | awk '{print $2}' > total-num-50-2-50asn-dna.xvg
sed -n 26,526p num-50-2-51asp-dna.xvg  | awk '{print $2}' > total-num-50-2-51asp-dna.xvg
sed -n 26,526p num-50-2-52glu-dna.xvg  | awk '{print $2}' > total-num-50-2-52glu-dna.xvg
sed -n 26,526p num-50-2-77GLN-dna.xvg  | awk '{print $2}' > total-num-50-2-77GLN-dna.xvg
sed -n 26,526p num-50-2-9tyr-dna.xvg   | awk '{print $2}' > total-num-50-2-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-50-1-13tyr-dna.xvg  | awk '{print $2}' > total-num-50-1-13tyr-dna.xvg
sed -n 26,526p num-50-1-31ile-dna.xvg  | awk '{print $2}' > total-num-50-1-31ile-dna.xvg
sed -n 26,526p num-50-1-50asn-dna.xvg  | awk '{print $2}' > total-num-50-1-50asn-dna.xvg
sed -n 26,526p num-50-1-51asp-dna.xvg  | awk '{print $2}' > total-num-50-1-51asp-dna.xvg
sed -n 26,526p num-50-1-52glu-dna.xvg  | awk '{print $2}' > total-num-50-1-52glu-dna.xvg
sed -n 26,526p num-50-1-77GLN-dna.xvg  | awk '{print $2}' > total-num-50-1-77GLN-dna.xvg
sed -n 26,526p num-50-1-9tyr-dna.xvg   | awk '{print $2}' > total-num-50-1-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-40-1-13tyr-dna.xvg  | awk '{print $2}' > total-num-40-1-13tyr-dna.xvg
sed -n 26,526p num-40-1-31ile-dna.xvg  | awk '{print $2}' > total-num-40-1-31ile-dna.xvg
sed -n 26,526p num-40-1-50asn-dna.xvg  | awk '{print $2}' > total-num-40-1-50asn-dna.xvg
sed -n 26,526p num-40-1-51asp-dna.xvg  | awk '{print $2}' > total-num-40-1-51asp-dna.xvg
sed -n 26,526p num-40-1-52glu-dna.xvg  | awk '{print $2}' > total-num-40-1-52glu-dna.xvg
sed -n 26,526p num-40-1-77GLN-dna.xvg  | awk '{print $2}' > total-num-40-1-77GLN-dna.xvg
sed -n 26,526p num-40-1-9tyr-dna.xvg   | awk '{print $2}' > total-num-40-1-9tyr-dna.xvg
                                                                                    
sed -n 26,526p num-30-2-13tyr-dna.xvg  | awk '{print $2}' > total-num-30-2-13tyr-dna.xvg
sed -n 26,526p num-30-2-31ile-dna.xvg  | awk '{print $2}' > total-num-30-2-31ile-dna.xvg
sed -n 26,526p num-30-2-50asn-dna.xvg  | awk '{print $2}' > total-num-30-2-50asn-dna.xvg
sed -n 26,526p num-30-2-51asp-dna.xvg  | awk '{print $2}' > total-num-30-2-51asp-dna.xvg
sed -n 26,526p num-30-2-52glu-dna.xvg  | awk '{print $2}' > total-num-30-2-52glu-dna.xvg
sed -n 26,526p num-30-2-77GLN-dna.xvg  | awk '{print $2}' > total-num-30-2-77GLN-dna.xvg
sed -n 26,526p num-30-2-9tyr-dna.xvg   | awk '{print $2}' > total-num-30-2-9tyr-dna.xvg

