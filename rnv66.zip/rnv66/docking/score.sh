#!/bin/csh

grep -A 0 'Score' total-vegf30.pdb > score30.txt
grep -A 0 'Score' total-vegf40.pdb > score40.txt
grep -A 0 'Score' total-vegf50.pdb > score50.txt
grep -A 0 'Score' total-vegf60.pdb > score60.txt
grep -A 0 'Score' total-vegf70.pdb > score70.txt
grep -A 0 'Score' total-vegf80.pdb > score80.txt
grep -A 0 'Score' total-vegf90.pdb > score90.txt

