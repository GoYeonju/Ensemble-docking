#!/bin/csh

cat vegf40*pdb > total-vegf40.pdb
cat vegf50*pdb > total-vegf50.pdb
cat vegf60*pdb > total-vegf60.pdb
cat vegf70*pdb > total-vegf70.pdb
cat vegf80*pdb > total-vegf80.pdb
cat vegf90*pdb > total-vegf90.pdb

