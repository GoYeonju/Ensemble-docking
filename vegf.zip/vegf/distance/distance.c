#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file;
    char *filename = "pd-BB.txt"; // 파일 이름을 적절히 변경하세요
    int number;
    int max = 0; // 최댓값 초기화
    int min = 10; // 최솟값 초기화

    // 파일 열기
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("파일을 열 수 없습니다.\n");
        return 1;
    }

    // 파일에서 숫자 읽기
    while (fscanf(file, "%d", &number) != EOF) {
        // 최댓값 갱신
        if (number > max) {
            max = number;
        }

        // 최솟값 갱신
        if (number < min) {
            min = number;
        }
    }

    // 파일 닫기
    fclose(file);

    // 최댓값과 최솟값 출력
    printf("최댓값: %d\n", max);
    printf("최솟값: %d\n", min);

    return 0;
}

