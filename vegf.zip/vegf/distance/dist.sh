#!/bin/csh

set i = 0 
while($i < 20)
set name = `printf "%02i" $i`

gmx distance -s vegf-cons30-$name.pdb -f vegf-cons30-$name.pdb -n vegf-pair.ndx -oall dist30AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons30-$name.pdb -f vegf-cons30-$name.pdb -n vegf-pair.ndx -oall dist30BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons30-$name.pdb -f vegf-cons30-$name.pdb -n vegf-pair.ndx -oall dist30AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons30-$name.pdb -f vegf-cons30-$name.pdb -n vegf-pair.ndx -oall dist30BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons40-$name.pdb -f vegf-cons40-$name.pdb -n vegf-pair.ndx -oall dist40AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons40-$name.pdb -f vegf-cons40-$name.pdb -n vegf-pair.ndx -oall dist40BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons40-$name.pdb -f vegf-cons40-$name.pdb -n vegf-pair.ndx -oall dist40AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons40-$name.pdb -f vegf-cons40-$name.pdb -n vegf-pair.ndx -oall dist40BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons50-$name.pdb -f vegf-cons50-$name.pdb -n vegf-pair.ndx -oall dist50AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons50-$name.pdb -f vegf-cons50-$name.pdb -n vegf-pair.ndx -oall dist50BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons50-$name.pdb -f vegf-cons50-$name.pdb -n vegf-pair.ndx -oall dist50AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons50-$name.pdb -f vegf-cons50-$name.pdb -n vegf-pair.ndx -oall dist50BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons60-$name.pdb -f vegf-cons60-$name.pdb -n vegf-pair.ndx -oall dist60AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons60-$name.pdb -f vegf-cons60-$name.pdb -n vegf-pair.ndx -oall dist60BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons60-$name.pdb -f vegf-cons60-$name.pdb -n vegf-pair.ndx -oall dist60AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons60-$name.pdb -f vegf-cons60-$name.pdb -n vegf-pair.ndx -oall dist60BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons70-$name.pdb -f vegf-cons70-$name.pdb -n vegf-pair.ndx -oall dist70AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons70-$name.pdb -f vegf-cons70-$name.pdb -n vegf-pair.ndx -oall dist70BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons70-$name.pdb -f vegf-cons70-$name.pdb -n vegf-pair.ndx -oall dist70AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons70-$name.pdb -f vegf-cons70-$name.pdb -n vegf-pair.ndx -oall dist70BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons80-$name.pdb -f vegf-cons80-$name.pdb -n vegf-pair.ndx -oall dist80AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons80-$name.pdb -f vegf-cons80-$name.pdb -n vegf-pair.ndx -oall dist80BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons80-$name.pdb -f vegf-cons80-$name.pdb -n vegf-pair.ndx -oall dist80AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons80-$name.pdb -f vegf-cons80-$name.pdb -n vegf-pair.ndx -oall dist80BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons90-$name.pdb -f vegf-cons90-$name.pdb -n vegf-pair.ndx -oall dist90AA-$name.xvg -select 'com of group "RBDA" plus com of group "HBDA"' -nopbc -rmpbc
gmx distance -s vegf-cons90-$name.pdb -f vegf-cons90-$name.pdb -n vegf-pair.ndx -oall dist90BB-$name.xvg -select 'com of group "RBDB" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons90-$name.pdb -f vegf-cons90-$name.pdb -n vegf-pair.ndx -oall dist90AB-$name.xvg -select 'com of group "RBDA" plus com of group "HBDB"' -nopbc -rmpbc
gmx distance -s vegf-cons90-$name.pdb -f vegf-cons90-$name.pdb -n vegf-pair.ndx -oall dist90BA-$name.xvg -select 'com of group "RBDB" plus com of group "HBDA"' -nopbc -rmpbc

	@ i = $i + 1
end




