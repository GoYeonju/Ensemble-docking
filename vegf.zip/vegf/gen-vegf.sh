#!/bin/csh

setenv OMP_NUM_THREADS 1 
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_30-pull.trr -s vegf_30-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons30-.pdb 
echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_40-pull.trr -s vegf_40-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons40-.pdb 
echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_50-pull.trr -s vegf_50-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons50-.pdb 
echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_60-pull.trr -s vegf_60-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons60-.pdb 
echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_70-pull.trr -s vegf_70-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons70-.pdb 
echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_80-pull.trr -s vegf_80-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons80-.pdb 
echo 1 | $GMXROOT/bin/gmx_mpi trjconv -f vegf_90-pull.trr -s vegf_90-pull.tpr -b 500 -dt 500 -pbc nojump -sep -nzero 2 -o vegf-cons90-.pdb 
