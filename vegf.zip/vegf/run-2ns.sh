#!/bin/csh

setenv OMP_NUM_THREADS 1 
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

$GMXROOT/bin/gmx_mpi grompp -p vegf_60.top -c vegf_60.gro -f min.mdp -o vegf_60-min.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm vegf_60-min
$GMXROOT/bin/gmx_mpi grompp -p vegf_60.top -c vegf_60-min.gro -f eq.mdp -o eq-2ns.tpr -maxwarn 1
$GMXROOT/bin/gmx_mpi mdrun -deffnm eq-2ns -gpu_id 0 
$GMXROOT/bin/gmx_mpi editconf -f eq-2ns.gro -o vegf-2ns.pdb  
