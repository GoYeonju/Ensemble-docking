#!/bin/csh

setenv OMP_NUM_THREADS 1 
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

$GMXROOT/bin/gmx_mpi grompp -p pull.top -n pull-gmx.ndx -c pull-gmx.pdb -f pull7.0.mdp -o vegf_70-pull.tpr -maxwarn 1 
$GMXROOT/bin/gmx_mpi mdrun -deffnm vegf_70-pull -gpu_id 1 
