#!/bin/csh


/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/amb2gro_top_gro.py -p pull.prmtop -c pull.inpcrd -g pull.gro -t pull.top -b pull-gmx.pdb


