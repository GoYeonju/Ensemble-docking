#!/bin/csh

setenv OMP_NUM_THREADS 1 
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-50-1-mol.xtc -s v7t1-50-1-eq2.tpr -b 10000 -n v7t1.ndx -num num-50-1
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-50-2-mol.xtc -s v7t1-50-2-eq2.tpr -b 10000 -n v7t1.ndx -num num-50-2
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-40-3-mol.xtc -s v7t1-40-3-eq2.tpr -b 10000 -n v7t1.ndx -num num-40-3
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-90-3-mol.xtc -s v7t1-90-3-eq2.tpr -b 10000 -n v7t1.ndx -num num-90-3
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-30-1-mol.xtc -s v7t1-30-1-eq2.tpr -b 10000 -n v7t1.ndx -num num-30-1
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-70-1-mol.xtc -s v7t1-70-1-eq2.tpr -b 10000 -n v7t1.ndx -num num-70-1
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-60-2-mol.xtc -s v7t1-60-2-eq2.tpr -b 10000 -n v7t1.ndx -num num-60-2
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-30-2-mol.xtc -s v7t1-30-2-eq2.tpr -b 10000 -n v7t1.ndx -num num-30-2
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-50-3-mol.xtc -s v7t1-50-3-eq2.tpr -b 10000 -n v7t1.ndx -num num-50-3
(echo 1 && echo 0) | $GMXROOT/bin/gmx_mpi hbond -f v7t1-30-3-mol.xtc -s v7t1-30-3-eq2.tpr -b 10000 -n v7t1.ndx -num num-30-3
