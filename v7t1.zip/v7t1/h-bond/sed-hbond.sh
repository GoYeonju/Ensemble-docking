#!/bin/csh

sed -n 26,526p  num-50-1.xvg | awk '{print $2}' > total-num-50-1.xvg
sed -n 26,526p  num-50-2.xvg | awk '{print $2}' > total-num-50-2.xvg
sed -n 26,526p  num-40-3.xvg | awk '{print $2}' > total-num-40-3.xvg
sed -n 26,526p  num-90-3.xvg | awk '{print $2}' > total-num-90-3.xvg
sed -n 26,526p  num-30-1.xvg | awk '{print $2}' > total-num-30-1.xvg
sed -n 26,526p  num-70-1.xvg | awk '{print $2}' > total-num-70-1.xvg
sed -n 26,526p  num-60-2.xvg | awk '{print $2}' > total-num-60-2.xvg
sed -n 26,526p  num-30-2.xvg | awk '{print $2}' > total-num-30-2.xvg
sed -n 26,526p  num-50-3.xvg | awk '{print $2}' > total-num-50-3.xvg
sed -n 26,526p  num-30-3.xvg | awk '{print $2}' > total-num-30-3.xvg
