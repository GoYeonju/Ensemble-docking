#!/bin/csh

setenv OMP_NUM_THREADS 1  
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

$GMXROOT/bin/gmx_mpi grompp -p v7t1-90-3.top -c v7t1-90-3.pdb -f min.mdp -o v7t1-90-3-min.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm v7t1-90-3-min
$GMXROOT/bin/gmx_mpi grompp -p v7t1-90-3.top -c v7t1-90-3-min.gro -f equi1.mdp -o v7t1-90-3-eq1.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm v7t1-90-3-eq1
$GMXROOT/bin/gmx_mpi grompp -p v7t1-90-3.top -c v7t1-90-3-eq1.gro -f eq.mdp -o v7t1-90-3-eq2.tpr
$GMXROOT/bin/gmx_mpi mdrun -deffnm v7t1-90-3-eq2
echo 0 | $GMXROOT/bin/gmx_mpi trjconv -f v7t1-90-3-eq2.trr -o v7t1-90-3-eq2.xtc 
rm v7t1-90-3-eq2.trr 
#rm v7t1-90-3-eq2.edr 
