#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/v7t1/docking/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com90-1.dat -cp $dir/com90-1.prmtop -rp $dir/com90-1-rec.prmtop -lp $dir/com90-1-lig.prmtop -y $dir/v7t1-90-1-eq2.xtc -sp $dir/com90-1-all.prmtop
