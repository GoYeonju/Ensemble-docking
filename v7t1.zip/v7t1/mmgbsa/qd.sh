#!/bin/csh

setenv OMP_NUM_THREADS 1 
setenv UTIL_DIR /gpfs/opt/ge2011/util
set GPU_ID = `${UTIL_DIR}/get_gpu_id`
set CPU_SUFFIX = `${UTIL_DIR}/get_cpu_type_suffix`
setenv GMXROOT /gpfs/opt/gmx2022${CPU_SUFFIX}
source $GMXROOT/bin/GMXRC.csh

$GMXROOT/bin/gmx_mpi trjconv -f v7t1-30-1-eq2.xtc -s v7t1-30-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-30-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-30-2-eq2.xtc -s v7t1-30-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-30-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-30-3-eq2.xtc -s v7t1-30-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-30-3-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-40-1-eq2.xtc -s v7t1-40-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-40-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-40-2-eq2.xtc -s v7t1-40-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-40-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-40-3-eq2.xtc -s v7t1-40-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-40-3-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-50-1-eq2.xtc -s v7t1-50-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-50-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-50-2-eq2.xtc -s v7t1-50-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-50-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-50-3-eq2.xtc -s v7t1-50-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-50-3-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-60-1-eq2.xtc -s v7t1-60-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-60-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-60-2-eq2.xtc -s v7t1-60-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-60-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-60-3-eq2.xtc -s v7t1-60-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-60-3-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-70-1-eq2.xtc -s v7t1-70-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-70-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-70-2-eq2.xtc -s v7t1-70-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-70-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-70-3-eq2.xtc -s v7t1-70-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-70-3-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-80-1-eq2.xtc -s v7t1-80-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-80-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-80-2-eq2.xtc -s v7t1-80-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-80-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-80-3-eq2.xtc -s v7t1-80-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-80-3-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-90-1-eq2.xtc -s v7t1-90-1-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-90-1-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-90-2-eq2.xtc -s v7t1-90-2-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-90-2-qd.pdb
$GMXROOT/bin/gmx_mpi trjconv -f v7t1-90-3-eq2.xtc -s v7t1-90-3-eq2.tpr -pbc mol -b 10000 -n qd.ndx -o v7t1-90-3-qd.pdb
