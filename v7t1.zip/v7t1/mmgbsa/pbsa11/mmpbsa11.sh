#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/v7t1/docking/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com60-2.dat -cp $dir/com60-2.prmtop -rp $dir/com60-2-rec.prmtop -lp $dir/com60-2-lig.prmtop -y $dir/v7t1-60-2-eq2.xtc -sp $dir/com60-2-all.prmtop
