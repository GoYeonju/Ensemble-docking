#!/bin/csh

grep -A 0 'Score' vegf30* | awk '{print $3}' > sc30.txt
grep -A 0 'Score' vegf40* | awk '{print $3}' > sc40.txt
grep -A 0 'Score' vegf50* | awk '{print $3}' > sc50.txt
grep -A 0 'Score' vegf60* | awk '{print $3}' > sc60.txt
grep -A 0 'Score' vegf70* | awk '{print $3}' > sc70.txt
grep -A 0 'Score' vegf80* | awk '{print $3}' > sc80.txt
grep -A 0 'Score' vegf90* | awk '{print $3}' > sc90.txt
paste pdb30.txt  sc30.txt  > score30.txt
paste pdb40.txt  sc40.txt  > score40.txt
paste pdb50.txt  sc50.txt  > score50.txt
paste pdb60.txt  sc60.txt  > score60.txt
paste pdb70.txt  sc70.txt  > score70.txt
paste pdb80.txt  sc80.txt  > score80.txt
paste pdb90.txt  sc90.txt  > score90.txt
