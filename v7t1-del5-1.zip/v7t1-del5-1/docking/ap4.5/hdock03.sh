#!/bin/csh

set hdock = "/gpfs/home/goyeonju/HDOCKlite-v1.1/hdock"
set createpl = "/gpfs/home/goyeonju/HDOCKlite-v1.1/createpl"

set i = 0 
while($i < 20)
set name = `printf "%02i" $i`
$hdock vegf/vegf-cons30-$name.pdb cons4.5-03.pdb -out vegf30-$name-cons4.5-03.out
$createpl vegf30-$name-cons4.5-03.out vegf30-$name-cons4.5-03.pdb  -nmax 1 -complex
$hdock vegf/vegf-cons40-$name.pdb cons4.5-03.pdb -out vegf40-$name-cons4.5-03.out
$createpl vegf40-$name-cons4.5-03.out vegf40-$name-cons4.5-03.pdb  -nmax 1 -complex
$hdock vegf/vegf-cons50-$name.pdb cons4.5-03.pdb -out vegf50-$name-cons4.5-03.out
$createpl vegf50-$name-cons4.5-03.out vegf50-$name-cons4.5-03.pdb  -nmax 1 -complex
$hdock vegf/vegf-cons60-$name.pdb cons4.5-03.pdb -out vegf60-$name-cons4.5-03.out
$createpl vegf60-$name-cons4.5-03.out vegf60-$name-cons4.5-03.pdb  -nmax 1 -complex
$hdock vegf/vegf-cons70-$name.pdb cons4.5-03.pdb -out vegf70-$name-cons4.5-03.out
$createpl vegf70-$name-cons4.5-03.out vegf70-$name-cons4.5-03.pdb  -nmax 1 -complex
$hdock vegf/vegf-cons80-$name.pdb cons4.5-03.pdb -out vegf80-$name-cons4.5-03.out
$createpl vegf80-$name-cons4.5-03.out vegf80-$name-cons4.5-03.pdb  -nmax 1 -complex
$hdock vegf/vegf-cons90-$name.pdb cons4.5-03.pdb -out vegf90-$name-cons4.5-03.out
$createpl vegf90-$name-cons4.5-03.out vegf90-$name-cons4.5-03.pdb  -nmax 1 -complex

	@ i = $i + 1
end

