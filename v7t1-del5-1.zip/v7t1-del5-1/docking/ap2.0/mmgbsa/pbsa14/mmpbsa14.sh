#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/v7t1-del5-1/docking/ap2.0/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com70-2.dat -cp $dir/com70-2.prmtop -rp $dir/com70-2-rec.prmtop -lp $dir/com70-2-lig.prmtop -y $dir/v7t1-del-70-2-eq2.xtc -sp $dir/com70-2-all.prmtop
