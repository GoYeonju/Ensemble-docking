#!/bin/csh

set mmpbsa = "/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/MMPBSA.py"
set dir = "/archive/goyeonju/project-docking/ensemble-docking/v7t1-del5-1/docking/ap2.0/mmgbsa"

$mmpbsa -O -i $dir/mmpbsa.in -o $dir/final_result-com40-1.dat -cp $dir/com40-1.prmtop -rp $dir/com40-1-rec.prmtop -lp $dir/com40-1-lig.prmtop -y $dir/v7t1-del-40-1-eq2.xtc -sp $dir/com40-1-all.prmtop
