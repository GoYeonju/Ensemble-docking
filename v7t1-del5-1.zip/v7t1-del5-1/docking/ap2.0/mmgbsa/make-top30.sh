#!/bin/bash

# Use . as the decimal separator
export LC_NUMERIC=en_US.UTF-8
# Rang and spacing of the reaction coordinate
MIN_WINDOW=1
MAX_WINDOW=3
WINDOW_STEP=1

for win in $(seq ${MIN_WINDOW} ${WINDOW_STEP} ${MAX_WINDOW})
do

/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/amb2gro_top_gro.py -p com30-$win-all.prmtop -c com30-$win-all.inpcrd -t v7t1-del-30-$win.top -g v7t1-del-30-$win.gro -b v7t1-del-30-$win.pdb
/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/amb2gro_top_gro.py -p com40-$win-all.prmtop -c com40-$win-all.inpcrd -t v7t1-del-40-$win.top -g v7t1-del-40-$win.gro -b v7t1-del-40-$win.pdb
/gpfs/home/goyeonju/.conda/envs/AmberTools22/bin/amb2gro_top_gro.py -p com50-$win-all.prmtop -c com50-$win-all.inpcrd -t v7t1-del-50-$win.top -g v7t1-del-50-$win.gro -b v7t1-del-50-$win.pdb

done

