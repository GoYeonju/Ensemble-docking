#!/bin/bash

# Use . as the decimal separator
export LC_NUMERIC=en_US.UTF-8

# Rang and spacing of the reaction coordinate
MIN_WINDOW=1
MAX_WINDOW=21
WINDOW_STEP=1

for win in $(seq ${MIN_WINDOW} ${WINDOW_STEP} ${MAX_WINDOW})
do

cd ./pbsa$win
qsub -cwd mmpbsa$win.sh -l mem=2g
cd ..

done
