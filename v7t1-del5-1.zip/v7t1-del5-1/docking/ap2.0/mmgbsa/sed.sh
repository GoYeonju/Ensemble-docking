#!/bin/bash

# Use . as the decimal separator
export LC_NUMERIC=en_US.UTF-8

# Rang and spacing of the reaction coordinate
MIN_WINDOW=1
MAX_WINDOW=3
WINDOW_STEP=1

for win in $(seq ${MIN_WINDOW} ${WINDOW_STEP} ${MAX_WINDOW})
do

head -n 4897 com30-$win.pdb > com30-$win-rec.pdb
tail -n 2724 com30-$win.pdb > com30-$win-lig.pdb
head -n 4897 com40-$win.pdb > com40-$win-rec.pdb
tail -n 2724 com40-$win.pdb > com40-$win-lig.pdb
head -n 4897 com50-$win.pdb > com50-$win-rec.pdb
tail -n 2724 com50-$win.pdb > com50-$win-lig.pdb
head -n 4897 com60-$win.pdb > com60-$win-rec.pdb
tail -n 2724 com60-$win.pdb > com60-$win-lig.pdb
head -n 4897 com70-$win.pdb > com70-$win-rec.pdb
tail -n 2724 com70-$win.pdb > com70-$win-lig.pdb
head -n 4897 com80-$win.pdb > com80-$win-rec.pdb
tail -n 2724 com80-$win.pdb > com80-$win-lig.pdb
head -n 4897 com90-$win.pdb > com90-$win-rec.pdb
tail -n 2724 com90-$win.pdb > com90-$win-lig.pdb

done
