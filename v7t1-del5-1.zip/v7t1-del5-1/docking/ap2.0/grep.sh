#!/bin/csh

grep -A 0 'Score' vegf30* | awk '{print $3}' > score30.txt
grep -A 0 'Score' vegf40* | awk '{print $3}' > score40.txt
grep -A 0 'Score' vegf50* | awk '{print $3}' > score50.txt
grep -A 0 'Score' vegf60* | awk '{print $3}' > score60.txt
grep -A 0 'Score' vegf70* | awk '{print $3}' > score70.txt
grep -A 0 'Score' vegf80* | awk '{print $3}' > score80.txt
grep -A 0 'Score' vegf90* | awk '{print $3}' > score90.txt

